[fileName dirName]=uigetfile('*.dat', 'xaa.dat');
fullname = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaa= horzcat(data2,data3,data4);
Labels_xaa = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xaa);


% For file 2
 
[fileName dirName]=uigetfile('*.dat', 'xab.dat');
fullname_xab = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xab,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xab= horzcat(data2,data3,data4);
Labels_xab = A{1:1,19:19};

% for File 3

[fileName dirName]=uigetfile('*.dat', 'xac.dat');
fullname_xac = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xac,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xac= horzcat(data2,data3,data4);
Labels_xac = A{1:1,19:19}
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);


% For file 4
 
[fileName dirName]=uigetfile('*.dat', 'xad.dat');
fullname_xad = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xad,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};
data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xad= horzcat(data2,data3,data4);
Labels_xad = A{1:1,19:19};


%file 5

[fileName dirName]=uigetfile('*.dat', 'xae.dat');
fullname_xae = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xae,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xae= horzcat(data2,data3,data4);
Labels_xae = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xae);


% For file 6
 
[fileName dirName]=uigetfile('*.dat', 'xaf.dat');
fullname_xaf = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xaf,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaf= horzcat(data2,data3,data4);
Labels_xaf = A{1:1,19:19}

% for File 7

[fileName dirName]=uigetfile('*.dat', 'xag.dat');
fullname_xag = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xag,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xag= horzcat(data2,data3,data4);
Labels_xag = A{1:1,19:19};
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);


Final_Training_Data_Option4 = [FinalData_xaa; FinalData_xab; FinalData_xac; FinalData_xad; FinalData_xae; FinalData_xaf; FinalData_xag]; 
Final_Training_Data_Option4 = Final_Training_Data_Option4(1:100,:);

%FinalTrainingData =[FinalData_xaa; FinalData_xab];
Labels= vertcat(Labels_xaa, Labels_xab, Labels_xac, Labels_xad, Labels_xae, Labels_xaf, Labels_xag); 
[labelrow labelcol]=size(Labels);

% renamin the labels from names to numbers for training data

renamedTrainingLabels_option3=zeros(labelrow,labelcol);
for i=1:labelrow
    
    if strcmp(Labels(i,:),'bus')
        disp('bus');
        renamedTrainingLabels_option3(i,1)=1;
    elseif strcmp(Labels(i,:),'saab')
               disp('saab');
              renamedTrainingLabels_option3(i,1)=2;
    elseif strcmp(Labels(i,:),'opel')
        disp('opel');
        renamedTrainingLabels_option3(i,1)=3;
        else 
            disp('van');
        renamedTrainingLabels_option3(i,1)=4;
     end
end
      

% for extracting testingfiles
% file 8
[fileName dirName]=uigetfile('*.dat', 'xah.dat');
fullname_xah = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xah,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xah= horzcat(data2,data3,data4);
Labels_xah = A{1:1,19:19};

% for file 9
[fileName dirName]=uigetfile('*.dat', 'xai.dat');
fullname_xai = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xai,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xai= horzcat(data2,data3,data4);
Labels_xai = A{1:1,19:19};

% now merging these two xah andxai files into one matrix

FinalTestingData_option4 = [FinalData_xah;FinalData_xai];
Final_Testing_Labels = [Labels_xah;Labels_xai];

[testingRowCount testingColCount] = size(Final_Testing_Labels);
       
%renaming class names with numbers
% renamin the labels
renamedTestingLabels_option4=zeros(testingRowCount,testingColCount);
for i=1:testingRowCount
    
    if strcmp(Final_Testing_Labels(i,:),'bus')
        disp('bus');
        renamedTestingLabels_option4(i,1)=1;
    elseif strcmp(Final_Testing_Labels(i,:),'saab')
               disp('saab');
              renamedTestingLabels_option4(i,1)=2;
    elseif strcmp(Final_Testing_Labels(i,:),'opel')
        disp('opel');
        renamedTestingLabels_option4(i,1)=3;
        else %if (strcmp(Labels(i,:),'van')
            disp('van');
        renamedTestingLabels_option4(i,1)=4;
     end
end


% calculate f
[N M]= size(Final_Training_Data_Option4);
f = [zeros(M*4+1,1);ones(3*N,1)];
 
%  for i=1:M*k+N*k
%      if (renamedTestingLabels == 1)
%          f(i,:) = [zeros(1,1), ones(1,1)]
%          f(i+1,:) = [zeros(1,1), zeros(1,1)]
%          f(i+2,:) = [zeros(1,1), zeros(1,1)]
%          f(i+3,:) = [zeros(1,1), eros(1,1)]
%          
%     elseif (renamedTestingLabels == 2)
%          f(i,:) = [zeros(1,1), zeros(1,1)]
%          f(i+1,:) = [zeros(1,1), ones(1,1)]
%          f(i+2,:) = [zeros(1,1), zeros(1,1)]
%          f(i+3,:) = [zeros(1,1), zeros(1,1)]
%          
%     elseif (renamedTestingLabels == 3)
%         f(i,:) = [zeros(1,1), zeros(1,1)]
%          f(i+1,:) = [zeros(1,1), zeros(1,1)]
%          f(i+2,:) = [zeros(1,1), ones(1,1)]
%          f(i+3,:) = [zeros(1,1), zeros(1,1)]
%      else 
%          f(i,:) = [zeros(1,1), zeros(1,1)]
%          f(i+1,:) = [zeros(1,1), zeros(1,1)]
%          f(i+2,:) = [zeros(1,1), zeros(1,1)]
%          f(i+3,:) = [zeros(1,1), ones(1,1)]
%      end
%  end
 
 
 
 %compute H
 h = [eye(4*M,4*M) zeros(4*M,3*N+1);zeros(3*N+1,4*M) zeros(3*N+1,3*N+1)];
 
%  for i=1:M*k
%      if (renamedTestingLabels == 1)
%          h(i,:) = [eye(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          
%     elseif (renamedTestingLabels == 2)
%          h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [eye(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          
%     elseif (renamedTestingLabels == 3)
%          h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [eye(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%      else 
%          h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [eye(1,M*k), zeros(1,N*k+1)]
%      end
%  end
%  
%  for i=M*k+1:N*k+1
%      if (renamedTestingLabels == 1)
%          h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          
%     elseif (renamedTestingLabels == 2)
%          h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          
%     elseif (renamedTestingLabels == 3)
%           h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%      else 
%          h(i,:) = [zeros(1,M*k) zeros(1,N*k+1)]
%          h(i+1,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+2,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%          h(i+3,:) = [zeros(1,M*k), zeros(1,N*k+1)]
%      end
%  end
%  
%  
 
 %compute g
 
 g=[ones(N*3)+73 ; zeros(N*3)];
%  for i=1:N*k
%      if (renamedTestingLabels == 1)
%          g(i,:) = [ones(1,1), zeros(1,1)]
%          g(i+1,:) = [zeros(1,1), zeros(1,1)]
%          g(i+2,:) = [zeros(1,1), zeros(1,1)]
%          g(i+3,:) = [zeros(1,1), zeros(1,1)]
%          
%     elseif (renamedTestingLabels == 2)
%          g(i,:) = [zeros(1,1), zeros(1,1)]
%          g(i+1,:) = [ones(1,1), zeros(1,1)]
%          g(i+2,:) = [zeros(1,1), zeros(1,1)]
%          g(i+3,:) = [zeros(1,1), zeros(1,1)]
%          
%     elseif (renamedTestingLabels == 3)
%          g(i,:) = [zeros(1,1), zeros(1,1)]
%          g(i+1,:) = [zeros(1,1), zeros(1,1)]
%          g(i+2,:) = [ones(1,1), zeros(1,1)]
%          g(i+3,:) = [zeros(1,1), zeros(1,1)]
%      else 
%          g(i,:) = [zeros(1,1), zeros(1,1)]
%          g(i+1,:) = [zeros(1,1), zeros(1,1)]
%          g(i+2,:) = [zeros(1,1), zeros(1,1)]
%          g(i+3,:) = [ones(1,1), zeros(1,1)]
%      end
%  end
%  
%  

% Design A Matrix
j=1;
 A =zeros(6*N,(N*3)+(M*4)+1);
 for i=1:N
%      if (renamedTestingLabels_option4 == 1)
         A(j,:) = [Final_Training_Data_Option4(i,:) -1*Final_Training_Data_Option4(i,:) zeros(1,18) zeros(1,18) 0 zeros(1,j-1) 1 ones(1,3*N-j)];
         A(j+1,:) = [Final_Training_Data_Option4(i,:) zeros(1,18) -1*Final_Training_Data_Option4(i,:) zeros(1,18) 0 zeros(1,j-1) 1 ones(1,3*N-j)];
         A(j+2,:) = [Final_Training_Data_Option4(i,:) zeros(1,18) zeros(1,18) -1*Final_Training_Data_Option4(i,:) 0 zeros(1,j-1) 1 ones(1,3*N-j)];
         A(j+3,:) = [Final_Training_Data_Option4(i,:) -1*Final_Training_Data_Option4(i,:) zeros(1,18) zeros(1,18) 0 zeros(1,j-1) 1 ones(1,3*N-j)];



for i=N+1:2*N;
%      if (renamedTestingLabels_option4 == 1)
         A(j,:) = [zeros(1,4*M)  0 zeros(1,j-1) 1 ones(1,3*N-j)];
         A(j+1,:) = [zeros(1,4*M) 0 zeros(1,j-1) 1 ones(1,3*N-j)];
         A(j+2,:) = [zeros(1,4*M) 0 zeros(1,j-1) 1 ones(1,3*N-j)];
         A(j+2,:) = [zeros(1,4*M) 0 zeros(1,j-1) 1 ones(1,3*N-j)];

end
   
%     elseif (renamedTestingLabels_option4 == 2)
%          A(j,:) = [-1*Final_Training_Data_Option4(i,:) Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) zeros(1,1) zeros(1,1) ones(1,1) zeros(1,1) zeros(1,1)];
%          A(j+1,:) = [zeros(1,1) Final_Training_Data_Option4(i,:) -1*Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) zeros(1,1) zeros(1,1) ones(1,1) zeros(1,1)];
%          A(j+2,:) = [zeros(1,1) Final_Training_Data_Option4(i,:) zeros(1,1) -1*Final_Training_Data_Option4(i,:)  zeros(1,1) zeros(1,1) zeros(1,1)  zeros(1,1) ones(1,1)];
%          
%    
%          
%     elseif (renamedTestingLabels_option4 == 3)
%          A(j,:) = [-1*Final_Training_Data_Option4(i,:)  zeros(1,1) Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) zeros(1,1) ones(1,1) zeros(1,1) zeros(1,1)];
%          A(j+1,:) = [zeros(1,1) -1*Final_Training_Data_Option4(i,:) Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) zeros(1,1) zeros(1,1) ones(1,1) zeros(1,1)];
%          A(j+2,:) = [zeros(1,1) zeros(1,1) Final_Training_Data_Option4(i,:) -1*Final_Training_Data_Option4(i,:)  zeros(1,1) zeros(1,1) zeros(1,1)  zeros(1,1) ones(1,1)];
            
%      else 
        
%          A(j,:) = [-1*Final_Training_Data_Option4(i,:)  zeros(1,1)  zeros(1,1) Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) ones(1,1) zeros(1,1) zeros(1,1)];
%          A(j+1,:) = [zeros(1,1) -1*Final_Training_Data_Option4(i,:)  zeros(1,1) Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) zeros(1,1) ones(1,1) zeros(1,1)];
%          A(j+2,:) = [zeros(1,1) zeros(1,1)  -1*Final_Training_Data_Option4(i,:)  Final_Training_Data_Option4(i,:) zeros(1,1) zeros(1,1) zeros(1,1)  zeros(1,1) ones(1,1)];
            
%      end
 end


%  for i= 1:N*k
%    
%     A(i,:) = -[renamedLabels(i)*(FinalData(i,:)) FinalData(i,:) zeros(1,M*k) zeros(1,M*k) zeros(1,M*k) zeros(1,(i-1)*k) 1 zeros(1,(N-i)*k)];
%     A(i+1,:) = -[renamedLabels(i)*(FinalData(i,:)) zeros(1,M*k) FinalData(i,:) zeros(1,M*k) zeros(1,M*k) zeros(1,(i-1)*k) 1 zeros(1,(N-i)*k)];
%     A(i+2,:) = -[renamedLabels(i)*(FinalData(i,:)) zeros(1,M*k) zeros(1,M*k) FinalData(i,:) zeros(1,M*k) zeros(1,(i-1)*k) 1 zeros(1,(N-i)*k)];
%     A(i+3,:) = -[renamedLabels(i)*(FinalData(i,:)) zeros(1,M*k) zeros(1,M*k) zeros(1,M*k) FinalData(i,:) zeros(1,(i-1)*k) 1 zeros(1,(N-i)*k)];
%  end
%  
%  n = N*k;
%  for i= 1:N*k
%    
%       A(n+i,:) = -[zeros(1,(M+1)*k) zeros(1,(i-1)*k) 1 zeros(1,(N-i)*k)];
%      
%  end
%  
 
 
 
 
 

%calculate quadprog
initialX = zeros (214, 1);
 exit=0;
%  global qp, isFirst = 1;
% %  while(exit ~= 1)
   options = optimset ( 'Algorithm', 'trust-region-reflective', 'Diagnostics', 'off', 'MaxIter', 10000);
%    if isFirst == 1
%        [qp, fVal, exitFlag] = quadprog(h,f,A,g, [], [], [], [], [] , options);
 [qp] = quadprog(h,f,A,g, [], [], [], [], [] , options);
%        isFirst =0;
%    else
%        [qp, fVal, exitFlag] = quadprog(h,f,A,g, [], [], [], [], [] , options);
%    end

%  exit = exitFlag;
%  initialX = qp;
%  
%  end
 
%  
%  exit = exitFlag;
%  initialX = qp;

%  exit = 1;
%  end
 
 w1 = qp(1:M);
 w2 = qp(M+1:2*M);
 w3 = qp((2*M)+1:3*M);
 w4 = qp((3*M)+1:4*M);
%  b = qp(M*4+1);
%  slack = qp(M*4+2:M*4+N*4+1);
 
 [rows_4 columns_4] = size(FinalTestingData_option4);
 
 dis_Step4=zeros(rows_4,4);
 
 for i=1:rows_4
     
    
     dis_Step4(i,1)=FinalTestingData_option4(i,:)*w1;
     dis_Step4(i,2)=FinalTestingData_option4(i,:)*w2;
     dis_Step4(i,3)=FinalTestingData_option4(i,:)*w3;
     dis_Step4(i,4)=FinalTestingData_option4(i,:)*w4;
     
 end
 
 
 %Assigning values according to the hyperplanes
 assignedTestingLabels= zeros(rows_4,1); 
 for i=1:rows_4
     data = [dis_Step4(i,1) dis_Step4(i,1) dis_Step4(i,1) dis_Step4(i,1)];
     [C,I] = max(data);
     assignedTestingLabels(i,1) = I;
 end
 
 
 
 
 count=0;
for i=1:rows_4
    if(renamedTestingLabels_option4(i,1)~=assignedTestingLabels(i,1))
        error_count_4=count+1;
    end
      
end

 
 