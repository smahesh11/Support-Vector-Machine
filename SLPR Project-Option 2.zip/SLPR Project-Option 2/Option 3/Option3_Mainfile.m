
[fileName dirName]=uigetfile('*.dat', 'xaa.dat');
fullname = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaa= horzcat(data2,data3,data4);
Labels_xaa = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xaa);


% For file 2
 
[fileName dirName]=uigetfile('*.dat', 'xab.dat');
fullname_xab = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xab,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xab= horzcat(data2,data3,data4);
Labels_xab = A{1:1,19:19};

% for File 3

[fileName dirName]=uigetfile('*.dat', 'xac.dat');
fullname_xac = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xac,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xac= horzcat(data2,data3,data4);
Labels_xac = A{1:1,19:19}
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);


% For file 4
 
[fileName dirName]=uigetfile('*.dat', 'xad.dat');
fullname_xad = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xad,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};
data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xad= horzcat(data2,data3,data4);
Labels_xad = A{1:1,19:19};


%file 5

[fileName dirName]=uigetfile('*.dat', 'xae.dat');
fullname_xae = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xae,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xae= horzcat(data2,data3,data4);
Labels_xae = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xae);


% For file 6
 
[fileName dirName]=uigetfile('*.dat', 'xaf.dat');
fullname_xaf = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xaf,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaf= horzcat(data2,data3,data4);
Labels_xaf = A{1:1,19:19}

% for File 7

[fileName dirName]=uigetfile('*.dat', 'xag.dat');
fullname_xag = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xag,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xag= horzcat(data2,data3,data4);
Labels_xag = A{1:1,19:19};
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);


Final_Training_Data_Option3 = [FinalData_xaa; FinalData_xab; FinalData_xac; FinalData_xad; FinalData_xae; FinalData_xaf; FinalData_xag]; 

%FinalTrainingData =[FinalData_xaa; FinalData_xab];
Labels= vertcat(Labels_xaa, Labels_xab, Labels_xac, Labels_xad, Labels_xae, Labels_xaf, Labels_xag); 
[labelrow labelcol]=size(Labels);

% renamin the labels from names to numbers for training data

renamedTrainingLabels=zeros(labelrow,labelcol);
for i=1:labelrow
    
    if strcmp(Labels(i,:),'bus')
        disp('bus');
        renamedTrainingLabels(i,1)=1;
    elseif strcmp(Labels(i,:),'saab')
               disp('saab');
              renamedTrainingLabels(i,1)=2;
    elseif strcmp(Labels(i,:),'opel')
        disp('opel');
        renamedTrainingLabels(i,1)=3;
        else 
            disp('van');
        renamedTrainingLabels(i,1)=4;
     end
end
      

% for extracting testingfiles
% file 8
[fileName dirName]=uigetfile('*.dat', 'xah.dat');
fullname_xah = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xah,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xah= horzcat(data2,data3,data4);
Labels_xah = A{1:1,19:19};

% for file 9
[fileName dirName]=uigetfile('*.dat', 'xai.dat');
fullname_xai = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xai,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xai= horzcat(data2,data3,data4);
Labels_xai = A{1:1,19:19};

% now merging these two xah and xai files into one matrix

FinalTestingData_option3 = [FinalData_xah;FinalData_xai];
Final_Testing_Labels = [Labels_xah;Labels_xai];

[testingRowCount testingColCount] = size(Final_Testing_Labels);
       
%renaming class names with numbers
% renaming the labels
renamedTestingLabels=zeros(testingRowCount,testingColCount);
for i=1:testingRowCount
    
    if strcmp(Final_Testing_Labels(i,:),'bus')
        disp('bus');
        renamedTestingLabels(i,1)=1;
    elseif strcmp(Final_Testing_Labels(i,:),'saab')
               disp('saab');
              renamedTestingLabels(i,1)=2;
    elseif strcmp(Final_Testing_Labels(i,:),'opel')
        disp('opel');
        renamedTestingLabels(i,1)=3;
        else %if (strcmp(Labels(i,:),'van')
            disp('van');
        renamedTestingLabels(i,1)=4;
     end
end

% For Testing purpose only
%Final_Training_Data_Option3 = Final_Training_Data_Option3(1:100,:);



% approach is to collect all the data points with Code Matrix1 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(Final_Training_Data_Option3);
trainingDataClassCodeMatrix1 = zeros(1,19);
classPairCount = 0;

for i=1:trainingRowCount
    
    trainingDataClassCodeMatrix1(i,1:18) = Final_Training_Data_Option3(i,:);
    trainingDataClassCodeMatrix1(i,19) = renamedTrainingLabels(i,1);

end


trainingDataClassCodeMatrix2 = trainingDataClassCodeMatrix1
trainingDataClassCodeMatrix3 = trainingDataClassCodeMatrix1;
trainingDataClassCodeMatrix4 = trainingDataClassCodeMatrix1;
trainingDataClassCodeMatrix5 = trainingDataClassCodeMatrix1;
trainingDataClassCodeMatrix6 = trainingDataClassCodeMatrix1;
trainingDataClassCodeMatrix7 = trainingDataClassCodeMatrix1;



% now find the hyper plane
% rename the class labels to find the plane for Code Matrix1
[rowcount Colcount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix1 =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassCodeMatrix1(i,19)== 1
                labelsForCodeMatrix1(i,1)=1;
    else
        labelsForCodeMatrix1(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs code matrix 1

[wC1,bC1,slackC3] = compute_QP(trainingDataClassCodeMatrix1,labelsForCodeMatrix1);

% now find the hyper plane for Code Matrix 2
% rename the class labels to find the plane by assigning +1 to code matrix
% and -1 respectively according to Code Matrix

[rowCount colCount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix2 =  zeros(rowcount,1);

for i=1:rowcount
    
    if trainingDataClassCodeMatrix2(i,19)== 2
                labelsForCodeMatrix2(i,1)=1;
    else
        labelsForCodeMatrix2(i,1) = -1;
    end
end

% computing hyper plane to classify code matrix2

[wC2,bC2,slackC2] = compute_QP(trainingDataClassCodeMatrix2,labelsForCodeMatrix2);

% now find the hyper plane for Code Matrix 3
% rename the class labels to find the plane by assigning +1 to code matrix
% and -1 respectively according to Code Matrix

[rowCount colCount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix3 =  zeros(rowcount,1);

for i=1:rowcount
    
    if trainingDataClassCodeMatrix3(i,19)== 3
                labelsForCodeMatrix3(i,1)=1;
    else
        labelsForCodeMatrix3(i,1) = -1;
               
     end
end

% computing hyper plane to classify code matrix3

[wC3,bC3,slackC3] = compute_QP(trainingDataClassCodeMatrix3,labelsForCodeMatrix3);


% now find the hyper plane for Code Matrix 4
% rename the class labels to find the plane by assigning +1 to code matrix
% and -1 respectively according to Code Matrix

[rowCount colCount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix4 =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassCodeMatrix4(i,19)== 4
                labelsForCodeMatrix4(i,1)=1;
    else
        labelsForCodeMatrix4(i,1) = -1;
               
     end
end

% computing hyper plane to classify code matrix4

[wC4,bC4,slackC4] = compute_QP(trainingDataClassCodeMatrix4,labelsForCodeMatrix4);



% now find the hyper plane for Code Matrix 5
% rename the class labels to find the plane by assigning +1 to code matrix
% and -1 respectively according to Code Matrix

[rowCount colCount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix5 =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassCodeMatrix5(i,19)== 1 || trainingDataClassCodeMatrix5(i,19)== 2
                labelsForCodeMatrix5(i,1)=1;
    else
        labelsForCodeMatrix5(i,1) = -1;
               
     end
end

% computing hyper plane to classify code matrix5

[wC5,bC5,slackC5] = compute_QP(trainingDataClassCodeMatrix5,labelsForCodeMatrix5);

% now find the hyper plane for Code Matrix 6
% rename the class labels to find the plane by assigning +1 to code matrix
% and -1 respectively according to Code Matrix

[rowCount colCount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix6 =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassCodeMatrix6(i,19)== 1 || trainingDataClassCodeMatrix6(i,19)== 3
                labelsForCodeMatrix6(i,1)=1;
    else
        labelsForCodeMatrix6(i,1) = -1;
               
     end
end

% computing hyper plane to classify code matrix6

[wC6,bC6,slackC6] = compute_QP(trainingDataClassCodeMatrix6,labelsForCodeMatrix6);



% now find the hyper plane for Code Matrix 7
% rename the class labels to find the plane by assigning +1 to code matrix
% and -1 respectively according to Code Matrix

[rowCount colCount]= size(Final_Training_Data_Option3)
labelsForCodeMatrix7 =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassCodeMatrix7(i,19)== 1 || trainingDataClassCodeMatrix7(i,19)== 2
                labelsForCodeMatrix7(i,1)=1;
    else
        labelsForCodeMatrix7(i,1) = -1;
               
     end
end

% computing hyper plane to classify code matrix7
[wC7,bC7,slackC7] = compute_QP(trainingDataClassCodeMatrix7,labelsForCodeMatrix7);


% Creading the Code Matrix
CodeMatrix = [1 -1 -1 -1 1 1 1;  -1 1 -1 -1 1 -1 -1;  -1 -1 1 -1 -1 1 -1; -1 -1 -1 1 -1 -1 1]
         
         
         
% Creating the Matrix for result for respective Hperplane Equations for
% every Testing Value
[distanceFromQpC1]= computeDistanceFromPlane(FinalTestingData_option3,wC1,bC1);
[distanceFromQpC2]= computeDistanceFromPlane(FinalTestingData_option3,wC2,bC2);
[distanceFromQpC3]= computeDistanceFromPlane(FinalTestingData_option3,wC3,bC3);
[distanceFromQpC4]= computeDistanceFromPlane(FinalTestingData_option3,wC4,bC4);
[distanceFromQpC5]= computeDistanceFromPlane(FinalTestingData_option3,wC5,bC5);
[distanceFromQpC6]= computeDistanceFromPlane(FinalTestingData_option3,wC6,bC6);
[distanceFromQpC7]= computeDistanceFromPlane(FinalTestingData_option3,wC7,bC7);

distanceFromQpC1= DistanceConversion( distanceFromQpC1 );
distanceFromQpC2= DistanceConversion( distanceFromQpC2 );
distanceFromQpC3= DistanceConversion( distanceFromQpC3 );
distanceFromQpC4= DistanceConversion( distanceFromQpC4 );
distanceFromQpC5= DistanceConversion( distanceFromQpC5 );
distanceFromQpC6= DistanceConversion( distanceFromQpC6 );
distanceFromQpC7= DistanceConversion( distanceFromQpC7 );


% Merging all the above Distances for All 7 Hyperplanes into one c Matrix

c = [distanceFromQpC1 distanceFromQpC2 distanceFromQpC3 distanceFromQpC4 distanceFromQpC5 distanceFromQpC6 distanceFromQpC7];

% Recognization Stage of the Classifier

%to be removed
%FinalTestingData_option3=FinalTestingData_option3(1:100,:);

[rowCount colCount]= size(FinalTestingData_option3);
assignedTestingLabels_Option3 = zeros(rowCount,1);
for i=1:rowCount 
    for j=1:4
    
   Var1(j)= (c(i,1)-CodeMatrix(j,1))^2;  
   Var1(j)=Var1(j) + (c(i,2)-CodeMatrix(j,2))^2;
   Var1(j)=Var1(j) + (c(i,3)-CodeMatrix(j,3))^2;
   Var1(j)=Var1(j) + (c(i,4)-CodeMatrix(j,4))^2;
   Var1(j)=Var1(j) + (c(i,5)-CodeMatrix(j,5))^2;
   Var1(j)=Var1(j) + (c(i,6)-CodeMatrix(j,6))^2;
   Var1(j)=Var1(j) + (c(i,7)-CodeMatrix(j,7))^2;
   Var1(j)= sqrt(Var1(j));
    
    end
             
    
     data = [Var1(1) Var1(2) Var1(3) Var1(4)];
     [C,I] = min(data);
     assignedTestingLabels_Option3(i,1) = I;
     
end

% Computing Error Count
errorCount_Option3=0;
for i=1:rowCount
    if(assignedTestingLabels_Option3(i,1)~= renamedTestingLabels(i,1))
        errorCount_Option3=errorCount_Option3+1;
    end
      
end

 
 Error_Option3=errorCount_Option3/rowCount;

         
         
         

         