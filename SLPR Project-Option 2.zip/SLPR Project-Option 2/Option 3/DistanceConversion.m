function [ distanceFromQpC ] = DistanceConversion( distanceFromQpC )

[Row Col]= size(distanceFromQpC);

for i=1:Row
     if(distanceFromQpC(i,1)<0)
          distanceFromQpC(i,1)= -1;
          
     else if(distanceFromQpC(i,1)>0)
        
          distanceFromQpC(i,1)= 1;
         else 
             % if the point is on the seperating plane then it may belong
             % to either of the classes
             distanceFromQpC(i,1)= 1;
         end
         
     end
     
 end



end

