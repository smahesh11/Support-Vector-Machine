 
[fileName dirName]=uigetfile('*.dat', 'xaa.dat');
fullname = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');


data = zeros(94,19);
[row col]=size(A{1:1,1:1});


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaa= horzcat(data2,data3,data4);
Labels_xaa = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xaa);


% For file 2

 
[fileName dirName]=uigetfile('*.dat', 'xab.dat');
fullname_xab = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xab,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');
data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};



data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xab= horzcat(data2,data3,data4);
Labels_xab = A{1:1,19:19};

% for File 3

[fileName dirName]=uigetfile('*.dat', 'xac.dat');
fullname_xac = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xac,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


% data = zeros(94,19);

% for i=1:19
% data=A,A{1:1,i:i});
% end

% A{1:1,1:1}
data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xac= horzcat(data2,data3,data4);
Labels_xac = A{1:1,19:19};
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);


% For file 4

 
[fileName dirName]=uigetfile('*.dat', 'xad.dat');
fullname_xad = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xad,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


% data = zeros(94,19);

% for i=1:19
% data=A,A{1:1,i:i});
% end

% A{1:1,1:1}
data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xad= horzcat(data2,data3,data4);
Labels_xad = A{1:1,19:19};


%file 5

[fileName dirName]=uigetfile('*.dat', 'xae.dat');
fullname_xae = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xae,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xae= horzcat(data2,data3,data4);
Labels_xae = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xae);


% For file 6
 
[fileName dirName]=uigetfile('*.dat', 'xaf.dat');
fullname_xaf = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xaf,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaf= horzcat(data2,data3,data4);
Labels_xaf = A{1:1,19:19};

% for File 7

[fileName dirName]=uigetfile('*.dat', 'xag.dat');
fullname_xag = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xag,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xag= horzcat(data2,data3,data4);
Labels_xag = A{1:1,19:19};
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);






Final_Training_Data = [FinalData_xaa; FinalData_xab; FinalData_xac; FinalData_xad; FinalData_xae; FinalData_xaf; FinalData_xag]; 

%FinalTrainingData =[FinalData_xaa; FinalData_xab];
Labels= vertcat(Labels_xaa, Labels_xab, Labels_xac, Labels_xad, Labels_xae, Labels_xaf, Labels_xag); 
[labelrow labelcol]=size(Labels);

% renamin the labels

renamedLabels=zeros(labelrow,labelcol);
for i=1:labelrow
    
    if strcmp(Labels(i,:),'bus')
        disp('bus');
        renamedLabels(i,1)=1;
    elseif strcmp(Labels(i,:),'saab')
               disp('saab');
              renamedLabels(i,1)=2;
    elseif strcmp(Labels(i,:),'opel')
        disp('opel');
        renamedLabels(i,1)=3;
        else %if (strcmp(Labels(i,:),'van')
            disp('van');
        renamedLabels(i,1)=4;
     end
end
      

% for extracting testingfiles
% file 8
[fileName dirName]=uigetfile('*.dat', 'xah.dat');
fullname_xah = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xah,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xah= horzcat(data2,data3,data4);
Labels_xah = A{1:1,19:19};

% for file 9
[fileName dirName]=uigetfile('*.dat', 'xai.dat');
fullname_xai = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xai,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xai= horzcat(data2,data3,data4);
Labels_xai = A{1:1,19:19};

% now merging these two xah and xai files into one matrix

Final_Testing_Data = [FinalData_xah;FinalData_xai];
Final_Testing_Labels = [Labels_xah;Labels_xai];

[labelrow1 labelcol1]=size(Final_Testing_Labels);
renamedTestingLabels=zeros(labelrow,labelcol);
for i=1:labelrow1
    
    if strcmp(Final_Testing_Labels(i,:),'bus')
        disp('bus');
        renamedTestingLabels(i,1)=1;
    elseif strcmp(Final_Testing_Labels(i,:),'saab')
               disp('saab');
              renamedTestingLabels(i,1)=2;
    elseif strcmp(Final_Testing_Labels(i,:),'opel')
        disp('opel');
        renamedTestingLabels(i,1)=3;
        else %if (strcmp(Labels(i,:),'van')
            disp('van');
        renamedTestingLabels(i,1)=4;
     end
end           


 

% We need to create function to calculate Qp for each Class
[renamedLabels1] = renamingLabels( renamedLabels,1 );

% func to compute hyperplane

[w1,b1,slack1] = compute_QPN(Final_Training_Data,renamedLabels1);

% Calculating the distances from hyperplane1 

 
% computing for 2nd plane
[renamedLabels2] = renamingLabels( renamedLabels,2 );
% comput hyper plane for 2nd 
[w2,b2,slack2] = compute_QPN(Final_Training_Data,renamedLabels2);


%  For Label 3
[renamedLabels3] = renamingLabels( renamedLabels,3 );

% To calculate the Hyperplane3 using Quadprog
[w3,b3,slack3] = compute_QPN(Final_Training_Data,renamedLabels3);

% Label 4
[renamedLabels4] = renamingLabels( renamedLabels,4 );
% To calculate the Hyperplane using Quaprog
[w4,b4,slack4] = compute_QPN(Final_Training_Data,renamedLabels4);

%Converting to double
Final_Testing_Data= double(Final_Testing_Data);


 % Calculating the distances from hyperplane1
 [distanceFromQp1]= computeDistanceFromPlane(Final_Testing_Data,w1,b1);
 % Calculating the distances from hyperplane2
 [distanceFromQp2]= computeDistanceFromPlane(Final_Testing_Data,w2,b2);
 
 % Calculating the distances from hyperplane3 
 [distanceFromQp3]= computeDistanceFromPlane(Final_Testing_Data,w3,b3);
 
 % Calculating the distances from hyperplane4
 [distanceFromQp4]= computeDistanceFromPlane(Final_Testing_Data,w4,b4);
 
 
 
 % need to assign labels based on the distances to each row 
 %labels are stored in testing labels
 [TestinNumOfRows TestinNumOfCols] = size(Final_Testing_Data);
 testingLabels= zeros(TestinNumOfRows,1);
 renamedTestingLabels= double(renamedTestingLabels);

 for i=1:TestinNumOfRows
      data = [distanceFromQp1(i,1) distanceFromQp2(i,1) distanceFromQp3(i,1) distanceFromQp4(i,1)];
     [C,I] = max(data);
     testingLabels(i,1) = I;
 end
 
 
 
  errorCount_Option1=0;
for i=1:TestinNumOfRows
    if(testingLabels(i,1)~= renamedTestingLabels(i,1))
        errorCount_Option1=errorCount_Option1+1;
    end
      
end

 
 Error_Option1=errorCount_Option1/TestinNumOfRows;
 
% Using SVM
% SVMStruct = svmtrain(Final_Training_Data,renamedLabels,'method','QP'); 


 

