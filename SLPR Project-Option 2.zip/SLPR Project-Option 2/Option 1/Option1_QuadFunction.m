function  qp = Project2_Option1AssigningY_Values(renamedLabels,Label,FinalData)

for i=1:labelrow
    
    if renamedLabels(i,1)==Label
                renamedLabels(i,1)=1;
    else
        renamedLabels(i,1)=-1;
               
     end
end




% To calculate the Hyperplane using Quadprog
[N M] = size(FinalData);
 A =zeros(2*N,N+M+1);
 for i= 1:N
   disp(A(i,:));
   disp([ren(i)*(renamedLabels(i,:)) renamedLabels(i) zeros(1,i-1) 1 zeros(1,N-i)]);
      A(i,:) = -[renamedLabels(i)*(FinalData(i,:)) renamedLabels(i) zeros(1,i-1) 1 zeros(1,N-i)];

 end
 
 n = N;
 for i= 1:N
   
      A(n+i,:) = -[zeros(1,M+1) zeros(1,i-1) 1 zeros(1,N-i)];
     
 end
 
 % calculate f
 f = [zeros(M+1,1);ones(N,1)];
 
 %compute H
 h = [eye(M,M) zeros(M,N+1);zeros(N+1,M) zeros(N+1,N+1)];
 
 %compute g
 g = -[ones(N,1) zeros(N,1)];
 
 
 %calculate quadprog
 qp = quadprog(h,f,A,g);
 
 
 
 
 


end
