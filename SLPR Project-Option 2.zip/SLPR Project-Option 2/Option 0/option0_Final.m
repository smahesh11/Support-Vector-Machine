 heart =load('HeartDataSet.mat')
 xtrain = full(heart.Xtrain);
 ytrain = full(heart.Ytrain);
 ytest = full(heart.Ytest);
 xtest = full(heart.Xtest);
 %get the size of the xtrain %
 [N M] = size(xtrain);
 
 %construct A matrix%
 A =zeros(2*N,N+M+1);
 for i= 1:N
   disp(A(i,:));
   disp([ytrain(i)*(xtrain(i,:)) ytrain(i) zeros(1,i-1) 1 zeros(1,N-i)]);
      A(i,:) = -[ytrain(i)*(xtrain(i,:)) ytrain(i) zeros(1,i-1) 1 zeros(1,N-i)];

 end
 
 n = N;
 for i= 1:N
   
      A(n+i,:) = -[zeros(1,M+1) zeros(1,i-1) 1 zeros(1,N-i)];
     
 end
 
 % calculATE f
 f = [zeros(14,1);(0.05*ones(200,1))];
 
 %compute H
 h = [eye(13,13) zeros(13,201);zeros(201,13) zeros(201,201)];
 
 %compute g
 g = -[ones(200,1) zeros(200,1)];
 
 
 %to calculate qp until it converges
 
 initialX = zeros (214, 1);
 exit=0;
 global qp, isFirst = 1;
%  while(exit ~= 1)
   options = optimset ( 'Algorithm', 'trust-region-reflective', 'Diagnostics', 'off', 'MaxIter', 9000);
%    if isFirst == 1
%        [qp, fVal, exitFlag] = quadprog(h,f,A,g, [], [], [], [], [] , options);
 [qp] = quadprog(h,f,A,g, [], [], [], [], [] , options);
%        isFirst =0;
%    else
%        [qp, fVal, exitFlag] = quadprog(h,f,A,g, [], [], [], [], [] , options);
%    end

%  exit = exitFlag;
%  initialX = qp;
%  
%  end
 
 
 w=qp(1:M);
 b=qp(M+1);
 slack=qp(M+2:M+N+1);
 
 
 % TO test the Testing sample data
 
 dis_0=zeros(70,1);
 
 for i=1:70
     
    dis_0(i,1)=xtest(i,:)*w+b;
     
     
 end
 
 disy_0=zeros(70,1);
 
 for i=1:70
     if(dis_0(i,1)<0)
          disy_0(i,1)= -1;
          
     else if(dis_0(i,1)>0)
        
          disy_0(i,1)= 1;
         else 
             % if the point is on the seperating plane then it may belong
             % to either of the classes
             disy_0(i,1)= 1;
         end
         
     end
     
 end
 
 
 count=0;
for i=1:70
    if(ytest(i,1)~=disy_0(i,1))
        count=count+1;
    end
      
end

 
 error_option1=count/70;
 
 
 
 