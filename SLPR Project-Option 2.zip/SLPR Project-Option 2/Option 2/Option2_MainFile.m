
[fileName dirName]=uigetfile('*.dat', 'xaa.dat');
fullname = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};


data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaa= horzcat(data2,data3,data4);
Labels_xaa = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xaa);


% For file 2
 
[fileName dirName]=uigetfile('*.dat', 'xab.dat');
fullname_xab = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xab,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xab= horzcat(data2,data3,data4);
Labels_xab = A{1:1,19:19};

% for File 3

[fileName dirName]=uigetfile('*.dat', 'xac.dat');
fullname_xac = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xac,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xac= horzcat(data2,data3,data4);
Labels_xac = A{1:1,19:19}
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);


% For file 4
 
[fileName dirName]=uigetfile('*.dat', 'xad.dat');
fullname_xad = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xad,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};
data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xad= horzcat(data2,data3,data4);
Labels_xad = A{1:1,19:19};


%file 5

[fileName dirName]=uigetfile('*.dat', 'xae.dat');
fullname_xae = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xae,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xae= horzcat(data2,data3,data4);
Labels_xae = A{1:1,19:19};
% we need to get the final label row count at the end
[labelrow labelcol]=size(Labels_xae);


% For file 6
 
[fileName dirName]=uigetfile('*.dat', 'xaf.dat');
fullname_xaf = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xaf,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xaf= horzcat(data2,data3,data4);
Labels_xaf = A{1:1,19:19}

% for File 7

[fileName dirName]=uigetfile('*.dat', 'xag.dat');
fullname_xag = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xag,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xag= horzcat(data2,data3,data4);
Labels_xag = A{1:1,19:19};
% we need to get the final label row count at the end
% [labelrow labelcol]=size(Labels_xac);

FinalTrainingData = [FinalData_xaa; FinalData_xab; FinalData_xac; FinalData_xad; FinalData_xae; FinalData_xaf; FinalData_xag]; 
Final_Training_Data = [FinalData_xaa; FinalData_xab; FinalData_xac; FinalData_xad; FinalData_xae; FinalData_xaf; FinalData_xag]; 

%FinalTrainingData =[FinalData_xaa; FinalData_xab];
Labels= vertcat(Labels_xaa, Labels_xab, Labels_xac, Labels_xad, Labels_xae, Labels_xaf, Labels_xag); 
[labelrow labelcol]=size(Labels);

% renamin the labels from names to numbers for training data

renamedTrainingLabels=zeros(labelrow,labelcol);
for i=1:labelrow
    
    if strcmp(Labels(i,:),'bus')
        disp('bus');
        renamedTrainingLabels(i,1)=1;
    elseif strcmp(Labels(i,:),'saab')
               disp('saab');
              renamedTrainingLabels(i,1)=2;
    elseif strcmp(Labels(i,:),'opel')
        disp('opel');
        renamedTrainingLabels(i,1)=3;
        else 
            disp('van');
        renamedTrainingLabels(i,1)=4;
     end
end
      

% for extracting testingfiles
% file 8
[fileName dirName]=uigetfile('*.dat', 'xah.dat');
fullname_xah = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xah,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xah= horzcat(data2,data3,data4);
Labels_xah = A{1:1,19:19};

% for file 9
[fileName dirName]=uigetfile('*.dat', 'xai.dat');
fullname_xai = fullfile(dirName, fileName);
A= zeros(11,19);
fid=fopen(fullname_xai,'rt');
A=textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s', ' ');

data = zeros(94,19);
[row col]=size(A{1:1,1:1});


New= A{1:1,1:1};

data2= horzcat(A{1:1,1:1},A{1:1,2:2},A{1:1,3:3},A{1:1,4:4},A{1:1,5:5},A{1:1,6:6},A{1:1,7:7},A{1:1,8:8});
data3 = horzcat(A{1:1,9:9},A{1:1,10:10},A{1:1,11:11},A{1:1,12:12},A{1:1,13:13},A{1:1,14:14},A{1:1,15:15},A{1:1,16:16});
data4 = horzcat(A{1:1,17:17},A{1:1,18:18});
FinalData_xai= horzcat(data2,data3,data4);
Labels_xai = A{1:1,19:19};

% now merging these two xah andxai files into one matrix

FinalTestingData = [FinalData_xah;FinalData_xai];
Final_Testing_Labels = [Labels_xah;Labels_xai];

[testingRowCount testingColCount] = size(Final_Testing_Labels);
       
%renaming class names with numbers
% renamin the labels
renamedTestingLabels=zeros(testingRowCount,testingColCount);
for i=1:testingRowCount
    
    if strcmp(Final_Testing_Labels(i,:),'bus')
        disp('bus');
        renamedTestingLabels(i,1)=1;
    elseif strcmp(Final_Testing_Labels(i,:),'saab')
               disp('saab');
              renamedTestingLabels(i,1)=2;
    elseif strcmp(Final_Testing_Labels(i,:),'opel')
        disp('opel');
        renamedTestingLabels(i,1)=3;
        else %if (strcmp(Labels(i,:),'van')
            disp('van');
        renamedTestingLabels(i,1)=4;
     end
end

% approach is to collect all the data points with classes 1 and 2 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(FinalTrainingData);
trainingDataClassOneTwo = zeros(1,19);
classPairCount = 0;
for i=1:trainingRowCount
    
    if renamedTrainingLabels(i,1) == 1 || renamedTrainingLabels(i,1) == 2
        classPairCount = classPairCount+1;
    trainingDataClassOneTwo(classPairCount,1:18) = FinalTrainingData(i,:);
     trainingDataClassOneTwo(classPairCount,19) = renamedTrainingLabels(i,1);
    end 
end

% now find the hyper plane 
% rename the class labels to find the plane by assigning +1 to class 1 and
% - 1 to class 2
[rowcount Colcount]= size(trainingDataClassOneTwo)
labelsForClassOneTwo =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassOneTwo(i,19)== 1
                labelsForClassOneTwo(i,1)=1;
    else
        labelsForClassOneTwo(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs 1 and 2

[w12,b12,slack12] = compute_QP_Option2(trainingDataClassOneTwo,labelsForClassOneTwo);



% approach is to collect all the data points with classes 1 and 3 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(FinalTrainingData);
trainingDataClassOneThree = zeros(1,18);
classPairCount = 0;
for i=1:trainingRowCount
    
    if renamedTrainingLabels(i,1) == 1 || renamedTrainingLabels(i,1) == 3
        classPairCount = classPairCount+1;
    trainingDataClassOneThree(classPairCount,1:18) = FinalTrainingData(i,1:18);
     trainingDataClassOneThree(classPairCount,19) = renamedTrainingLabels(i,1);
    end 
end

% now find the hyper plane  h(13)
% rename the class labels to find the plane by assigning +1 to class 1 and
% - 1 to class 3
[rowcount Colcount]= size(trainingDataClassOneThree)
labelsForClassOneThree =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassOneThree(i,19)== 1
                labelsForClassOneThree(i,1)=1;
    else
        labelsForClassOneThree(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs 1 and 3
[w13,b13,slack13] = compute_QP_Option2(trainingDataClassOneThree,labelsForClassOneThree);


% approach is to collect all the data points with classes 1 and 4 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(FinalTrainingData);
trainingDataClassOneFour = zeros(1,18);
classPairCount = 0;
for i=1:trainingRowCount
    
    if renamedTrainingLabels(i,1) == 1 || renamedTrainingLabels(i,1) == 4
        classPairCount = classPairCount+1;
    trainingDataClassOneFour(classPairCount,1:18) = FinalTrainingData(i,1:18);
      trainingDataClassOneFour(classPairCount,19) = renamedTrainingLabels(i,1);
    end 
end

% now find the hyper plane  h(14)
% rename the class labels to find the plane by assigning +1 to class 1 and
% - 1 to class 3
[rowcount Colcount]= size(trainingDataClassOneFour)
labelsForClassOneFour =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassOneFour(i,19)== 1
                labelsForClassOneFour(i,1)=1;
    else
        labelsForClassOneFour(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs 1 and 4
[w14,b14,slack14] = compute_QP_Option2(trainingDataClassOneFour,labelsForClassOneFour);


% approach is to collect all the data points with classes 2 and 3 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(FinalTrainingData);
trainingDataClassTwoThree = zeros(1,18);
classPairCount = 0;
for i=1:trainingRowCount
        if renamedTrainingLabels(i,1) == 2 || renamedTrainingLabels(i,1) == 3
        classPairCount = classPairCount+1;
    trainingDataClassTwoThree(classPairCount,1:18) = FinalTrainingData(i,1:18);
    trainingDataClassTwoThree(classPairCount,19) = renamedTrainingLabels(i,1);
    end 
end

% now find the hyper plane  h(23)
% rename the class labels to find the plane by assigning +1 to class 2 and
% - 1 to class 3
[rowcount Colcount]= size(trainingDataClassTwoThree)
labelsForClassTwoThree =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassTwoThree(i,19)== 2
                labelsForClassTwoThree(i,1)=1;
    else
        labelsForClassTwoThree(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs 2 and 3
[w23,b23,slack23] = compute_QP_Option2(trainingDataClassTwoThree,labelsForClassTwoThree);


% approach is to collect all the data points with classes 2 and 4 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(FinalTrainingData);
trainingDataClassTwoFour = zeros(1,18);
classPairCount = 0;
for i=1:trainingRowCount
        if renamedTrainingLabels(i,1) == 2 || renamedTrainingLabels(i,1) == 4
        classPairCount = classPairCount+1;
    trainingDataClassTwoFour(classPairCount,1:18) = FinalTrainingData(i,1:18);
     trainingDataClassTwoFour(classPairCount,19) = renamedTrainingLabels(i,1);
    end 
end
% now find the hyper plane  h(24)
% rename the class labels to find the plane by assigning +1 to class 2 and
% - 1 to class 4
[rowcount Colcount]= size(trainingDataClassTwoFour)
labelsForClassTwoFour =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassTwoFour(i,19)== 2
                labelsForClassTwoFour(i,1)=1;
    else
        labelsForClassTwoFour(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs 2 and 4
[w24,b24,slack24] = compute_QP_Option2(trainingDataClassTwoFour,labelsForClassTwoFour);


% approach is to collect all the data points with classes 3 and 4 and find
% the hyper plane seperating them only
[trainingRowCount trainingColCount]= size(FinalTrainingData);
trainingDataClassThreeFour = zeros(1,18);
classPairCount = 0;
for i=1:trainingRowCount
        if renamedTrainingLabels(i,1) == 3 || renamedTrainingLabels(i,1) == 4
        classPairCount = classPairCount+1;
    trainingDataClassThreeFour(classPairCount,1:18) = FinalTrainingData(i,1:18);
     trainingDataClassThreeFour(classPairCount,19) = renamedTrainingLabels(i,1);
    end 
end

% now find the hyper plane  h(34)
% rename the class labels to find the plane by assigning +1 to class 2 and
% - 1 to class 4
[rowcount Colcount]= size(trainingDataClassThreeFour)
labelsForClassThreeFour =  zeros(rowcount,1);
for i=1:rowcount
    
    if trainingDataClassThreeFour(i,19)== 3
                labelsForClassThreeFour(i,1)=1;
    else
        labelsForClassThreeFour(i,1) = -1;
               
     end
end

% computing hyper plane to classify classs 3 and 4
[w34,b34,slack34] = compute_QP_Option2(trainingDataClassThreeFour,labelsForClassThreeFour);
 
%  all the distances must be chnaged 
% use the function

 
 % Calculating the distances from hyperplane12 
  [TestinNumOfRows TestinNumOfCols] = size(FinalTestingData);
 distanceFromQp12=zeros(TestinNumOfRows,1);
 
 for i=1:TestinNumOfRows
     
    distanceFromQp12(i)=FinalTestingData(i,:)*w12+b12;
 end

 % Calculating the distances from hyperplane13 
  [TestinNumOfRows TestinNumOfCols] = size(FinalTestingData);
 distanceFromQp13=zeros(TestinNumOfRows,1);
 
 for i=1:TestinNumOfRows
     
    distanceFromQp13(i,1)=FinalTestingData(i,:)*w13+b13;
 end

 % Calculating the distances from   hyperplane14
  [TestinNumOfRows TestinNumOfCols] = size(FinalTestingData);
 distanceFromQp14=zeros(TestinNumOfRows,1);
 
 for i=1:TestinNumOfRows
     
    distanceFromQp14(i,1)=FinalTestingData(i,:)*w14+b14;
 end

 % Calculating the distances from hyperplane23 
  [TestinNumOfRows TestinNumOfCols] = size(FinalTestingData);
 distanceFromQp23=zeros(TestinNumOfRows,1);
 
 for i=1:TestinNumOfRows
     
    distanceFromQp23(i,1)=FinalTestingData(i,:)*w23+b23;
 end
 
 % Calculating the distances from hyperplane24
  [TestinNumOfRows TestinNumOfCols] = size(FinalTestingData);
 distanceFromQp24 = zeros(TestinNumOfRows,1);
 
 for i=1:TestinNumOfRows
     
    distanceFromQp24(i,1)=FinalTestingData(i,:)*w24+b24;
 end
 
 % Calculating the distances from hyperplane34 
  [TestinNumOfRows TestinNumOfCols] = size(FinalTestingData);
 distanceFromQp34=zeros(TestinNumOfRows,1);
 
 
 for i=1:TestinNumOfRows
     
    distanceFromQp34(i,1)=FinalTestingData(i,:)*w34+b34;
 end
 
 
 % assign the labels based on comparing the distance from planes and
 % finding the max
 % first catgory distnces in an array by summing up 
 
 % firstly finding the sum of 1st category hyper plane distace
 firstCategoryDistance = zeros(TestinNumOfRows,1);
 secondCategoryDistance = zeros(TestinNumOfRows,1);
 thirdCategoryDistance = zeros(TestinNumOfRows,1);
 fourthCategoryDistance = zeros(TestinNumOfRows,1);
 
 %keep a track of count values for eachof category
 countOfClass1 = zeros(TestinNumOfRows,1);
 countOfClass2= zeros(TestinNumOfRows,1);
 countOfClass3 = zeros(TestinNumOfRows,1);
 countOfClass4 = zeros(TestinNumOfRows,1);
%  global
 class1Count=0, class2Count =0, class3Count =0 ,class4Count =0;
 
 % classify the samples based on the max number of times a point is
 % classified to belong to that category
 
 for i=1:TestinNumOfRows
     class1Count =0, class2Count =0, class3Count =0 ,class4Count =0;
     if distanceFromQp12(i,1) > 0
         % then it belongs to class 1 or 2 otherwise
         class1Count = class1Count+1;
         countOfClass1(i,1) = class1Count;
     else
          class2Count = class2Count+1;
         countOfClass2(i,1) = class2Count;
     end
      if distanceFromQp13(i,1) > 0
         % then it belongs to class 1 or 2 otherwise
         class1Count = class1Count+1;
         countOfClass1(i,1) = class1Count;
      else
         class3Count = class3Count+1;
         countOfClass3(i,1) = class3Count;
      end
      if distanceFromQp14(i,1) > 0
         % then it belongs to class 1 or 2 otherwise
         class1Count = class1Count+1;
         countOfClass1(i,1) = class1Count;
      else
         class4Count = class4Count+1;
         countOfClass4(i,1) = class4Count;
      end
      if distanceFromQp23(i,1) > 0
         % then it belongs to class 1 or 2 otherwise
         class2Count = class2Count+1;
         countOfClass2(i,1) = class2Count;
      else
         class3Count = class3Count+1;
         countOfClass3(i,1) = class3Count;
      end
      if distanceFromQp24(i,1) > 0
         % then it belongs to class 1 or 2 otherwise
         class2Count = class2Count+1;
         countOfClass2(i,1) = class2Count;
      else
         class4Count = class4Count+1;
         countOfClass4(i,1) = class4Count;
      end
      if distanceFromQp34(i,1) > 0
         % then it belongs to class 1 or 2 otherwise
         class3Count = class3Count+1;
         countOfClass3(i,1) = class3Count;
      else
         class4Count = class4Count+1;
         countOfClass4(i,1) = class4Count;
     end

 end
 
 
 
 

%  % now find max of the above values to decide testing data category
 assignedTestingLabels= zeros(TestinNumOfRows,1); 
 for i=1:TestinNumOfRows
     data = [countOfClass1(i,1) countOfClass2(i,1) countOfClass3(i,1) countOfClass4(i,1)];
     [C,I] = max(data);
     assignedTestingLabels(i,1) = I;
 end
 
 % computing the error percentage
 errorCount_Option2=0;
for i=1:TestinNumOfRows
    if(assignedTestingLabels(i,1)~= renamedTestingLabels(i,1))
        errorCount_Option2=errorCount_Option2+1;
    end
      
end

 
 Error_Option2=errorCount_Option2/TestinNumOfRows;
 
 
 