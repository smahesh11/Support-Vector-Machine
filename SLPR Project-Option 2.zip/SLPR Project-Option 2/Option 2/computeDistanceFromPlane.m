function [ distanceFromQp ] = computeDistanceFromPlane( Final_Testing_Data,w,b )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

 [TestinNumOfRows TestinNumOfCols] = size(Final_Testing_Data);
 distanceFromQp = zeros(TestinNumOfRows,1);
 
 for i=1:TestinNumOfRows
         distanceFromQp(i,1) = Final_Testing_Data(i,:)*w-b;
 end
  
end

