function [ renamedLabels ] = RenamingLabels( renamedLabels,label )
[rowcount Colcount]= size(renamedLabels)
for i=1:rowcount
    
    if renamedLabels(i,1)== label
                renamedLabels(i,1)=1;
    else
        renamedLabels(i,1)=-1;
               
     end
end


end

