function [ w,b,slack ] = compute_QP(Final_Training_Data,renamedLabels)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[N M] = size(Final_Training_Data);
M= M-1;
 A =zeros(2*N,N+M+1);
 for i= 1:N
   disp(A(i,:));
   disp([renamedLabels(i,:)*(Final_Training_Data(i,1:18)) renamedLabels(i,:) zeros(1,i-1) 1 zeros(1,N-i)]);
      A(i,:) = -[renamedLabels(i,:)*(Final_Training_Data(i,1:18)) renamedLabels(i,:) zeros(1,i-1) 1 zeros(1,N-i)];

 end
 
 n = N;
 for i= 1:N
   
      A(n+i,:) = -[zeros(1,M+1) zeros(1,i-1) 1 zeros(1,N-i)];
     
 end
 
 % calculate f
 f = [zeros(M+1,1);(0.6*ones(N,1))];
 
 %compute H
 h = [eye(M,M) zeros(M,N+1);zeros(N+1,M) zeros(N+1,N+1)];
 
 %compute g
 g = -[ones(N,1) zeros(N,1)];
 
 
 %calculate quadprog
 initialX = zeros (214, 1);
 exit=0;
 global qp, isFirst=1;
 while(exit ~= 1)
   options = optimset ( 'Algorithm', 'active-set', 'Diagnostics', 'off', 'MaxIter', 10000);
   if isFirst == 1
       [qp, fVal, exitFlag] = quadprog(h,f,A,g, [], [], [], [], [] , options);
       isFirst = 0;
   else  
       [qp, fVal, exitFlag] = quadprog(h,f,A,g, [], [], [], [], initialX , options);
   end
 
 exit = exitFlag;
 initialX = qp;

 exit = 1;
 end
 
 w = qp(1:M);
 b = qp(M+1);
 slack = qp(M+2:M+N+1);

end

